
/*
 * Copyright (C) Zhu Jiashun
 * Copyright (C) Zaver
 */

#ifndef ERROR_H
#define ERROR_H

#define ZV_OK       0
#define ZV_ERROR    -1

#endif
