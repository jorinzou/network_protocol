#include <pthread.h>
#include <string.h>
#include <stdio.h>

#include "socket.h"
#include "cmd.h"

void send_user_name(void)
{
    char user_name[] = {"USER zze\r\n"};
    send_buf(cmd_sockfd, user_name, sizeof(user_name)-1);
}

void send_passwd(void)
{
    char passwd[] = {"PASS root\r\n"};
    send_buf(cmd_sockfd, passwd, sizeof(passwd)-1);
}

/*被动模式,ftp server会打开端口，让client去连接*/
void send_pasv(void)
{
    char pasv[] = {"PASV\r\n"};
    send_buf(cmd_sockfd, pasv, sizeof(pasv)-1);
}

void get_file(void)
{
    char get[] = {"RETR linux-3.2.1.tar.bz2\r\n"};
    send_buf(data_sockfd, get, sizeof(get)-1);
}

void do_data_sock(int sockfd)
{
    unsigned char read_buf[1024] = {0};
   int len = read(sockfd,read_buf,sizeof(read_buf));
   if (len <= 0){
        perror("read");
        DEBUG_INFO("read");
        /*缓存区无数据可读,Resource temporarily unavailable*/
        if(errno == EINTR/*读取数据过程中被中断*/ || errno == EAGAIN 
            || errno == EWOULDBLOCK){
            /*在VxWorks和Windows上，EAGAIN的名字叫做EWOULDBLOCK*/
		    DEBUG_INFO("EINTR,EAGAIN,EWOULDBLOCK");
			return;
		}
        close(sockfd);
        return;
   }

   DEBUG_INFO("%s",read_buf);
}

void *ftp_data_thread(void *arg)
{
    pthread_detach(pthread_self());
    data_sockfd = socket_init();
    if (data_sockfd < 0){
        DEBUG_INFO("socket_init error");
        return NULL;
    }
    int ret;//发送三次握手报文
    ret = connect_server(data_port,ip_str,data_sockfd);
    if(ret < 0){
        DEBUG_INFO("connect_server error");
        return NULL;
    }
    
    int i = 0;
    struct pollfd pollfds[1];
    while(1){
    	pollfds[0].fd=data_sockfd;
    	pollfds[0].events=POLLIN;
    	int num = poll(pollfds,1,-1);
        for(i=0; i < num; ++i){
            if(pollfds[i].revents & POLLIN){
    		    do_data_sock(pollfds[0].fd);
    	    }
        }
    }
}

void connect_ftp_server(void)
{
    pthread_t t1;
    pthread_create(&t1,NULL,ftp_data_thread,NULL);
}


void *cmd_do_pthread(void *arg)
{
   pthread_detach(pthread_self());
   char user_input[1024] = {0};
   while(1){
        printf("ftp>");
        memset(user_input,0,sizeof(user_input));
        fgets(user_input,sizeof(user_input),stdin);
        user_input[strlen(user_input)-1] = '\0';//去掉回车
        if (!strcmp(user_input,"user")){
           send_user_name(); 
        }
        else if (!strcmp(user_input,"passwd")){
            send_passwd();
        }
        else if (!strcmp(user_input,"pasv")){
            send_pasv();
        }
        else if (!strcmp(user_input,"connect")){
            connect_ftp_server();
        }
        else if (!strcmp(user_input,"get")){
            get_file();
        }
   }
}

