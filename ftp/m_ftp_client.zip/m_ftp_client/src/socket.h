#ifndef _SOCKET_CLIENT_H
#define _SOCKET_CLIENT_H
#include <stdint.h>
#include <getopt.h>
#include <signal.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <poll.h>
#include <pthread.h>

#include "debug.h"
#include "cmd.h"

extern int cmd_sockfd;
extern int data_sockfd;
extern unsigned short data_port;
extern char ip_str[16];

#define SERVER_PORT 21
#define SERVER_IP "172.16.8.189"

int send_buf(int fd, void *buf, size_t n) ;
int socket_init(void);
void *client_do_pthread(void *arg);

#endif

