#include "socket.h"

int cmd_sockfd = -1;
int data_sockfd = -1;
unsigned short data_port = -1;
char ip_str[16] = {0};

int socket_init(void)
{
    int sockfd = -1;
    int optval=1;
    struct sockaddr_in serveraddr;
  
    /* Create a socket descriptor */
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("socket");
	    return -1;
    }
 
    /* Eliminates "Address already in use" error from bind. */
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,(const void *)&optval , sizeof(int)) < 0){
        perror("setsockopt");
	    return -1;
    }
    return sockfd;
} 

int connect_server(int port ,const char *ipaddr,int sockfd)
{
	struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
	server_addr.sin_addr.s_addr=inet_addr(ipaddr);;
    
    int ret = connect(sockfd,(struct sockaddr*)&server_addr,sizeof(struct sockaddr));
    if (ret < 0){
        perror("connect");
        DEBUG_INFO("connect server failed");
        return -1;
    }
     /*设置成非阻塞*/
    unsigned long ul = 1;
    ioctl(sockfd, FIONBIO, &ul); 
    DEBUG_INFO("connect server sucessful");
    return 0;
}
int send_buf(int fd, void *buf, size_t n) 
{
    size_t nleft = n;
    int nwritten;
    char *bufp = (char *)buf;
        
    while (nleft > 0) {
        if ((nwritten = write(fd, bufp, nleft)) <= 0) {
            if (errno == EINTR || errno == EAGAIN)  /* interrupted by sig handler return */
                nwritten = 0;    /* and call write() again */
            else {
                DEBUG_INFO("%s", strerror(errno));
                perror("write");
                return -1;       /* errorno set by write() */
            }
        }
        nleft -= nwritten;
        bufp += nwritten;
    }
    return n;
}

void do_ip_and_port(char *buf)
{
    int i = 0;
    unsigned char arr[6] = {0};
    char *ptr = strtok(buf,",");
    while(ptr != NULL){
        arr[i++] = atoi(ptr);
        ptr = strtok(NULL,",");
    }
    data_port = (arr[4] <<8) | arr[5];
    sprintf(ip_str,"%d.%d.%d.%d",arr[0],arr[1],arr[2],arr[3]);
    DEBUG_INFO("ip=%s,port=%d",ip_str,data_port);
}

void do_socket(int sockfd)
{
   unsigned char read_buf[1024] = {0};
   int len = read(sockfd,read_buf,sizeof(read_buf));
   if (len <= 0){
        perror("read");
        DEBUG_INFO("read");
        /*缓存区无数据可读,Resource temporarily unavailable*/
        if(errno == EINTR/*读取数据过程中被中断*/ || errno == EAGAIN 
            || errno == EWOULDBLOCK){
            /*在VxWorks和Windows上，EAGAIN的名字叫做EWOULDBLOCK*/
		    DEBUG_INFO("EINTR,EAGAIN,EWOULDBLOCK");
			return;
		}
        close(sockfd);
        return;
   }

   if (strstr(read_buf,"220")){//服务端返回欢迎消息
      DEBUG_INFO("ftp server return hello msg:%s",read_buf);
   }
   else if(strstr(read_buf,"331")){//发送登录名返回成功
        DEBUG_INFO("ftp client login return:%s",read_buf);
   }
   else if(strstr(read_buf,"530")){//发送登录密码返回成功
        DEBUG_INFO("ftp client login return:%s",read_buf);
   }
   else if (strstr(read_buf,"227")){//服务端返回动态开放端口和ip
        DEBUG_INFO("%s",read_buf);
        int i = 0;
        char *start = NULL;
        char *end = NULL;
        for(i; i < len; ++i){
            if (read_buf[i] == '('){
                start = &read_buf[i+1];
            }
            if(read_buf[i] == ')'){
                end = &read_buf[i-1];
            }
        }
        char str_ip_port[32] = {0};
        strncpy(str_ip_port,start,end-start+1);
        do_ip_and_port(str_ip_port);
   }
}

void *client_do_pthread(void *arg)
{
    pthread_detach(pthread_self());
    cmd_sockfd = socket_init();
    if (cmd_sockfd < 0){
        DEBUG_INFO("socket_init error");
        return NULL;
    }
    int ret;//发送三次握手报文
    ret = connect_server(SERVER_PORT,SERVER_IP,cmd_sockfd);
    if(ret < 0){
        DEBUG_INFO("connect_server error");
        return NULL;
    }
    
    int i = 0;
    struct pollfd pollfds[1];
    while(1){
    	pollfds[0].fd=cmd_sockfd;
    	pollfds[0].events=POLLIN;
    	int num = poll(pollfds,1,-1);
        for(i=0; i < num; ++i){
            if(pollfds[i].revents & POLLIN){
    		    do_socket(pollfds[0].fd);
    	    }
        }
    }
}

