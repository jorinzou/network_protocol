#ifndef _CMD_H_
#define _CMD_H_
#include <time.h>
#include <sys/time.h>

void *cmd_do_pthread(void *arg);

#endif
